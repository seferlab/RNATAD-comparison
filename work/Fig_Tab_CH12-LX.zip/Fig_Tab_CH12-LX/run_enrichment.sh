#!/bin/bash

mkdir -p log
mkdir -p output
nohup python3 TAD_boundary_enrichment_analysis.py CTCF marks/wgEncodeSydhTfbsCh12CtcfbIggrabPk.narrowPeak >log/ctcf.log&
nohup python3 TAD_boundary_enrichment_analysis.py H3K4me3 marks/wgEncodeSydhHistCh12H3k4me3IggyalePk.narrowPeak >log/H3k4me3.log&
nohup python3 TAD_boundary_enrichment_analysis.py H3K36me3 marks/wgEncodePsuHistoneCh12H3k36me3FImmortal2a4bInputPk.broadPeak >log/H3k36me3.log&
nohup python3 TAD_boundary_enrichment_analysis.py SMC3 marks/wgEncodeSydhTfbsCh12Smc3ab9263IggrabPk.narrowPeak >log/smc3.log&
nohup python3 TAD_boundary_enrichment_analysis.py polII marks/wgEncodeSydhTfbsCh12Pol2s2IggrabPk.narrowPeak >log/PolII.log&
