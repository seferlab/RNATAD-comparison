#!/bin/bash

mkdir -p TADadjRsquared
mkdir -p log

chromList2=($(seq 1 22)) 
chromList2[${#chromList2[*]}]=X

runTADadjRsquared(){
list=($(seq $1 $2))
for li in ${list[@]}; do
data=`printf "HIC%03d" $li`
nohup  Rscript TADadjRsquared.r -i ../Rao/${data}/${data}_50k_KR.chr1 -d ${data} -c $3 -o TADadjRsquared/${data}.TADadjRsquared >log/${data}_TADadjRsquared.log 2>&1 &
done
}
runTADadjRsquared 1 29 22
#runTADadjRsquared 50 56 22
#runTADadjRsquared 69 74 22
#runTADadjRsquared 65 67 22
#runTADadjRsquared 80 82 22
#runTADadjRsquared 94 98 19
