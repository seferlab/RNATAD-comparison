#!/bin/bash

mkdir -p TADadjRsquared
mkdir -p log

nohup Rscript TADadjRsquared_drosophila.r -i ../Kc167/primary_10k_KR.chr2L -d Kc167_primary  -o TADadjRsquared/Kc167_primary.TADadjRsquared >log/Kc167_primary_TADadjRsquared.log 2>&1 &

nohup Rscript TADadjRsquared_drosophila.r -i ../Kc167/replicate_10k_KR.chr2L -d Kc167_replicate -o TADadjRsquared/Kc167_replicate.TADadjRsquared >log/Kc167_replicate_TADadjRsquared.log 2>&1 &

