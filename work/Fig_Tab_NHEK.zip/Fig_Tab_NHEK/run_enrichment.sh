#!/bin/bash

mkdir -p log
mkdir -p output
nohup python3 TAD_boundary_enrichment_analysis.py CTCF marks/wgEncodeAwgTfbsBroadNhekCtcfUniPk.narrowPeak >log/ctcf.log&
nohup python3 TAD_boundary_enrichment_analysis.py H3K4me3 marks/wgEncodeUwHistoneNhekH3k4me3StdPkRep1.narrowPeak >log/H3K4me3.log&
nohup python3 TAD_boundary_enrichment_analysis.py H3K36me3 marks/wgEncodeUwHistoneNhekH3k36me3StdPkRep1.narrowPeak >log/H3K36me3.log&
nohup python3 TAD_boundary_enrichment_analysis.py Housekeeping_genes marks/HK.txt >log/HK.log&
nohup python3 TAD_boundary_TSS_analysis.py  >log/TSS.log&
